<?php

$host="180.211.92.131";
$user="jayatta";
$pass="bm5092da";
$db="budget";


$koneksi=mysql_connect($host,$user,$pass);
$database=mysql_select_db($db,$koneksi);
$tanggal=date('d-M-y');
/*
if ($koneksi)
{
	echo "berhasil : )";
}else{
	echo "Gagal !";
}
*/
?>
