<?php
if (isset($_POST['submit']))
{
	include "koneksi.php";
	error_reporting(0);
  $email=$_POST['email'];
  $password=$_POST['password'];
	$nama=ucwords($_POST['nama']);
	$tanggal_lahir=$_POST['tanggal_lahir'];
  $no_telp=$_POST['no_telp'];
	$status=$_POST['status'];
	if (!empty($nama)  && !empty($password) && !empty($email) && !empty($tanggal_lahir) && !empty($no_telp) )
	{

		$cek=mysql_query("SELECT * FROM mahasiswa WHERE `email`='$email'");
		$valid=mysql_num_rows($cek);

		if ($valid){
			?>
			<script language="javascript">alert("Maaf, Email Anda sudah ada yang punya!!");</script>
			<script> document.location.href='index.php'; </script>
			<?php
		}else{

				$insert=mysql_query("INSERT INTO mahasiswa(img,email,password,nama,tanggal_lahir,no_telp,status)
                            values('no_img.JPEG','$email','$password','$nama','$tanggal_lahir','$no_telp','$status')");
				if ($insert){
					?>
					<script language="javascript">alert("Kamu berhasil mendaftar, silahkan login lagi!!");</script>
					<script> document.location.href='index.php'; </script>
					<?php
				}
			}
	}
	else
	{
		?>
		<script language="javascript">alert("Maaf, Data yang anda kirim belum lengkap!!");</script>
		<script> document.location.href='index.php'; </script>
		<?php
	}

}
?>
