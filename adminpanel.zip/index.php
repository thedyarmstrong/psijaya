<!DOCTYPE html>
<html lang="zxx">

<head>
	<title>Fakultas Psikologi Universitas Jayabaya</title>
	<!-- custom-theme -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Treasurer Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script type="application/x-javascript">
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!-- //custom-theme -->
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/slicebox.css" rel="stylesheet" type="text/css">
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/style2.css" rel="stylesheet">
	<!-- font-awesome-icons -->
	<link href="css/font-awesome.css" rel="stylesheet">
	<!-- //font-awesome-icons -->
	<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic'
	    rel='stylesheet' type='text/css'>
	<link href="//fonts.googleapis.com/css?family=Raleway:100i,200,200i,300,400,500,500i,600,700,700i,800,800i" rel="stylesheet">

	<!-- testimonial link -->
	<link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">
	<script src="https://use.fontawesome.com/5a8a7bb461.js"></script>

</head>

<body>
	<!-- banner -->
	<div class="agileits_top_menu">

		<div class="w3l_header_left">
			<ul>
				<li><i class="fa fa-map-marker" aria-hidden="true"></i> 13210 Jakarta</li>
				<li><i class="fa fa-phone" aria-hidden="true"></i> +62 21 4700 890</li>
				<li><i class="fa fa-envelope-o" aria-hidden="true"></i> <a href="mailto:psikologi@jayabaya.ac.id">psikologi@jayabaya.ac.id</a></li>
			</ul>
		</div>
		<div class="w3l_header_right">
			<div class="w3ls-social-icons text-left">
				<a class="facebook" href="#"><i class="fa fa-facebook"></i></a>
				<a class="twitter" href="#"><i class="fa fa-twitter"></i></a>
			</div>
		</div>
		<div class="clearfix"> </div>
	</div>
	<div class="agileits_w3layouts_banner_nav">
		<nav class="navbar navbar-default">
			<div class="navbar-header navbar-left">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
				<h1><a class="navbar-brand" href="index.php"><i class="fa fa-graduation-cap" aria-hidden="true"></i><span>Psikologi Jayabaya</span></a></h1>

			</div>
			<ul class="agile_forms">
				<li><a class="active" href="#" data-toggle="modal" data-target="#myModal2"> Login</a> </li>
				<li><a href="#" data-toggle="modal" data-target="#myModal3"> Daftar</a> </li>
			</ul>
			<!-- Collect the nav links, forms, and other content for toggling -->
			<div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
				<nav>
					<ul class="nav navbar-nav">
						<li class="active"><a href="index.php" class="hvr-underline-from-center">Home</a></li>
						<li><a href="about.html" class="hvr-underline-from-center">About</a></li>
						<li><a href="penelitian.html" class="hvr-underline-from-center">Penelitian</a></li>
						<li class="dropdown">
							<a href="#" class="dropdown-toggle hvr-underline-from-center" data-toggle="dropdown">Program Perkuliahan<b class="fa fa-caret-down"></b></a>
							<ul class="dropdown-menu agile_short_dropdown">
								<li><a href="kelasreguler.html">Kelas Reguler</a></li>
								<li><a href="kelaskhusus.html">Kelas Khusus</a></li>
							</ul>
						</li>
						<li><a href="contact.html" class="hvr-underline-from-center">Contact</a></li>
						<li class="dropdown">
							<a href="#" class="dropdown-toggle hvr-underline-from-center" data-toggle="dropdown">TAUTAN<b class="fa fa-caret-down"></b></a>
							<ul class="dropdown-menu agile_short_dropdown">
								<li><a href="http://117.102.107.205/">SIAK</a></li>
								<li><a href="http://fpsiuj.siakad.my.id/">SIAK (NEW)</a></li>
								<li><a href="http://fakpsijayabaya.blogspot.co.id/">Blog</a></li>
							</ul>
					</ul>
				</nav>

			</div>
		</nav>

		<div class="clearfix"> </div>
	</div>
	<!-- Modal1 -->
	<div class="modal fade" id="myModal2" tabindex="-1" role="dialog">
		<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>

					<div class="signin-form profile">
						<h3 class="agileinfo_sign">Login</h3>
						<div class="login-form">
							<form action="login.php?op=in" method="POST">
								<input type="email" name="email" placeholder="E-mail" required="">
								<input type="password" name="password" placeholder="Password" required="">
								<div class="tp">
									<button type="submit" class="btn btn-success" name="submit" style="success">Sign In</button>
								</div>
							</form>
						</div>
						<div class="login-social-grids">
							<ul>
								<li><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#"><i class="fa fa-rss"></i></a></li>
							</ul>
						</div>
						<p><a href="#" data-toggle="modal" data-target="#myModal3"> Don't have an account?</a></p>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- //Modal1 -->
	<!-- Modal2 -->
	<div class="modal fade" id="myModal3" tabindex="-1" role="dialog">
		<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>

					<div class="signin-form profile">
						<h3 class="agileinfo_sign">Daftar</h3>
						<div class="login-form">
							<form action="daftar.php" method="POST">
								<input type="email" name="email" placeholder="Email" required="">
								<input type="password" name="password" id="password1" placeholder="Password" required="">
								<input type="text" name="nama" placeholder="Nama Lengkap" required="">
								<label>Tanggal Lahir : <input type="date" name="tanggal_lahir" required=""></label>
								<input type="text" name="no_telp" placeholder="Nomor Telepon" required="">
								<input type="text" class="hidden" name="status" value="Pendaftar" required="">

								<button type="submit" class="btn btn-success" name="submit" style="success">Daftar Menjadi Mahasiswa</button>
							</form>
						</div>
						<p><a href="#">Klik disini untuk melihat persyaratan!!</a></p>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- //Modal2 -->


	<div class="banner">


		<div class="wrapper">

			<ul id="sb-slider" class="sb-slider">

				<?php
				include "koneksi.php";
				$sql=mysql_query("SELECT * FROM `banner` ORDER BY `noid` DESC LIMIT 4");
				while($d=mysql_fetch_array($sql)) {?>

				<li>
					<a href="images/<?php echo $d['img']; ?>"><img src="images/<?php echo $d['img']; ?>" alt="<?php echo $d['img']; ?>"/></a>
					<div class="sb-description">
						<p><?php echo $d['nama']; ?></p>
					</div>
				</li>

<?php } ?>
			</ul>

			</ul>

			<div id="shadow" class="shadow"></div>

			<div id="nav-arrows" class="nav-arrows">
				<a href="#">Next</a>
				<a href="#">Previous</a>
			</div>

			<div id="nav-dots" class="nav-dots">
				<span class="nav-dot-current"></span>
				<span></span>
				<span></span>
				<span></span>

			</div>
		</div>
		<!-- /wrapper -->
	</div>
	<!-- banner-bottom -->
	<div class="banner-bottom">
		<div class="container">
			<div class="mid_agile_bannner_top_info">
				<h2>Fakultas Psikologi Universitas Jayabaya</h2>
				<div class="heading-underline">
					<div class="h-u1"></div>
					<div class="h-u2"></div>
					<div class="h-u3"></div>
					<div class="clearfix"></div>
				</div>
			</div>
			<div class="col-md-6 agileits_banner_bottom_left">
				<h3><span>Psikologi Jayabaya</span></h3>
				<p class="w3l_para">Fakultas Psikologi Universitas Jayabaya didirikan pada tanggal 28 Oktober 2002 sesuai SK
					pendirian Program Studi  Nomor: 3199/D/T/2002. Pada awal didirikan,
					Fakultas Psikologi Jayabaya bekerjasama dengan Fakultas Psikologi Universitas Padjadjaran (UNPAD) Bandung
					dalam bentuk bantuan dosen dan pengembangan kurikulum.</p>
				<div class="w3l_social_icons">
					<div class="w3l_social_icon_grid">
						<p class="w3l_para">Dekan pertama Fakultas Psikologi Jayabaya adalah Prof. Dr. Bill S. Raksadjaya.
							Setelah 16 tahun sejak berdiri, Fakultas Psikologi Jayabaya saat ini terus berbenah diri untuk menjawab
							tantangan perkembangan ilmu dan teknologi melalui perubahan kurikulum
							dengan konten Human factors dan psychological engineering.</p>
					</div>
				</div>
			</div>

			<div class="col-md-6 agileits_banner_bottom_right">
				<div class="w3ls_banner_bottom_right">
					<img src="images/gedung.webp" alt=" " class="img-responsive" />

				</div>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
	<!-- //banner-bottom -->

	<!-- News -->

	<div class="w3l-news-content events">
		<div class="container">
			<h3 class="tittle_agile_w3">Penelitian Psikologi</h3>
			<div class="heading-underline">
				<div class="h-u1"></div>
				<div class="h-u2"></div>
				<div class="h-u3"></div>
				<div class="clearfix"></div>
			</div>

	<div class="w3l-news_info_agile_its">
	<div class="col-md-6 w3l-news">
		<?php
		include "koneksi.php";
		$sql=mysql_query("SELECT foto,judul,link,date_format(tanggal,'%d %M %Y') AS tanggal,isi,link FROM berita ORDER BY noid DESC LIMIT 3");
			while ($d=mysql_fetch_array($sql))

		{?>
		<div class="media response-info">

		<div class="media-left response-text-left">
			<a href="#" data-toggle="modal" data-target="#myModal">
				<img class="media-object" src="images/<?php echo $d['foto'];?>" alt="" width="223px" height="213px">
			</a>
		</div>
		<div class="media-body response-text-right">
			<h5><?php echo $d['judul']; ?></h5>
				<ul>
					<li><i class="fa fa-calendar" aria-hidden="true"></i>
						<?php echo $d['tanggal']; ?>
					</li>
				</ul>
				<p><?php echo $d['isi']; ?></p>
				<div class="read">
					<a href="<?php echo $d['link'];?>" class="view resw3">Read More</a>
				</div>
		</div>

		<div class="clearfix"> </div>
	</div>
	<?php } ?>

	<div class="clearfix"> </div>
</div>


				<div class="col-md-6 w3l_about_bottom_right">
					 <h3 class="tittle_agile_w3 why">Agenda Psikologi</h3>
				    <div class="heading-underline">
						<div class="h-u1"></div><div class="h-u2"></div><div class="h-u3"></div><div class="clearfix"></div>
					</div>
					<div class="panel-group w3l_panel_group_faq" id="accordion" role="tablist" aria-multiselectable="true">

						<?php
						include "koneksi.php";
						$sql=mysql_query("SELECT * FROM agenda ORDER BY noid DESC");

						$i=1;

							while ($d=mysql_fetch_array($sql))

						{?>

						<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingThree">
						  <h4 class="panel-title asd">
								<?php echo $i++; ?>. <?php echo $d['agen']; ?>
							</a>
						  </h4>
						</div>
					  </div>

					<?php } ?>


					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!-- //News -->
	<!-- events-top -->

	<!-- Gallery Kegiatan -->
		<div class="services">
			 <div class="container">
				 <h3 class="tittle_agile_w3">Gallery Kegiatan</h3>
					<div class="heading-underline">
					<div class="h-u1"></div><div class="h-u2"></div><div class="h-u3"></div><div class="clearfix"></div>
				</div>
			<ul class="portfolio_agile_info_w3ls">

				<?php
				include "koneksi.php";
				$sql=mysql_query("SELECT * FROM `kegiatan` ORDER BY `noid` DESC LIMIT 9");
				while($d=mysql_fetch_array($sql)) {?>
					<li>
						<div class="agile_events_top_grid">
							<div class="w3_agileits_evets_text_img">
								<a href="images/<?php echo $d['img']; ?>" class="lsb-preview" data-lsb-group="header">
									<div class="view view-eighth">
										<img src="images/<?php echo $d['img']; ?>" alt=" " class="img-responsive" width="400px" height="200px">
										<div class="mask">
											<i class="fa fa-eye" aria-hidden="true"></i>
										</div>
									</div>
								</a>
							</div>
							<div class="agileits_w3layouts_events_text port_info_agile">
								<h3><?php echo $d['nama']; ?></h3>
							</div>
						</div>
					</li>
				<?php } ?>

			</ul>
		</div>
	</div>
	<!-- //Gallery Kegiatan -->

	<!-- team -->
		<div class="services">
			<div class="container">
					     <h3 class="tittle_agile_w3">Lecturer</h3>
			    <div class="heading-underline">
					<div class="h-u1"></div><div class="h-u2"></div><div class="h-u3"></div><div class="clearfix"></div>
				</div>
				<div class="w3_services_grids">
					<div class="col-md-3 w3ls_team_grid">
						<div class="w3ls_team_grid1 hover15">
							<figure>
								<img src="images/Dr. Widura Imam Mustopo.jpg" alt=" " class="img-responsive" style="height:300px;"/>
							</figure>
							<div class="w3ls_team_grid1_pos">
								<ul class="social-icons">
								<li><a href="http://psikologipenerbangan.blogspot.co.id/"><i class="fa fa-rss fa-2x"></i></a></li>
								<li><a href="#"><i class="fa fa-facebook-official fa-2x"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter-square fa-2x"></i></a></li>
								</ul>
							</div>
						</div>
						<h4>Dr. Widura Imam Mustopo</h4>
						<p>Dekan</p>
					</div>
					<div class="col-md-3 w3ls_team_grid">
						<div class="w3ls_team_grid1 hover15">
							<figure>
								<img src="images/Dra. Lydia Indira M.Psi2.jpg" alt=" " class="img-responsive" style="height:300px;"/>
							</figure>
							<div class="w3ls_team_grid1_pos">
								<ul class="social-icons">
								<li><a href="http://psikologipenerbangan.blogspot.co.id/"><i class="fa fa-rss fa-2x"></i></a></li>
								<li><a href="#"><i class="fa fa-facebook-official fa-2x"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter-square fa-2x"></i></a></li>
								</ul>
							</div>
						</div>
						<h4>Dra. Lydia Indira M.Psi</h4>
						<p>Wakil Dekan 2</p>
					</div>
					<div class="col-md-3 w3ls_team_grid">
						<div class="w3ls_team_grid1 hover15">
							<figure>
								<img src="images/Dra. Esiyannera MM.jpg" alt=" " class="img-responsive" style="height:300px;"/>
							</figure>
							<div class="w3ls_team_grid1_pos">
								<ul class="social-icons">
								<li><a href="http://psikologipenerbangan.blogspot.co.id/"><i class="fa fa-rss fa-2x"></i></a></li>
								<li><a href="#"><i class="fa fa-facebook-official fa-2x"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter-square fa-2x"></i></a></li>
								</ul>
							</div>
						</div>
						<h4>Dra. Esiyannera MM</h4>
						<p>Wakil Dekan 3 & Kepala Unit Penjaminan Mutu</p>
					</div>
					<div class="col-md-3 w3ls_team_grid">
						<div class="w3ls_team_grid1 hover15">
							<figure>
								<img src="images/Dra. Sri Mulyani M.Psi.jpg" alt=" " class="img-responsive" style="height:300px;"/>
							</figure>
							<div class="w3ls_team_grid1_pos">
								<ul class="social-icons">
								<li><a href="http://psikologipenerbangan.blogspot.co.id/"><i class="fa fa-rss fa-2x"></i></a></li>
								<li><a href="#"><i class="fa fa-facebook-official fa-2x"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter-square fa-2x"></i></a></li>
								</ul>
							</div>
						</div>
						<h4>Dra. Sri Mulyani M.Psi</h4>
						<p>Kepala Lab</p>
					</div>
					<div class="clearfix"> </div>
				</div>
			</div>
		</div>
	<!-- //team -->


<!-- testimonials -->
	<div class="container" id="testibungkus">
	<div class="row">
		<div class="col-sm-12">
        <h3><strong>Testimonial Alumni</strong></h3>
        <div class="seprator"></div>
            <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
              <!-- Wrapper for slides -->
              <div class="carousel-inner">
                <div class="item active">
                  <div class="row" style="padding: 20px">
                    <button style="border: none;"><i class="fa fa-quote-left testimonial_fa" aria-hidden="true"></i></button>
                    <p class="testimonial_para">Penggemblengan Mental" kalimat itu yang pertama kali saya ingat ketika saya
											berkuliah di Fakultas Psikologi UJ.
											Konsep pengenalan diri yang dibangun dalam suasana kekeluargaan oleh dosen-dosen disana,
											secara tidak sadar membentuk mental saya ke arah yang positif.
											Hal tersebutlah yang terbawa ketika saya aktif dalam organisasi kemahasiswaan,
											hingga ditempat saat ini saya bekerja.<br><br>
											Dosen yang berpengalaman, serta memiliki kualitas di bidangnya masing-masing,
											membantu saya memiliki bekal dalam berkarir di dunia kerja.
											Bersyukur saya dapat berkarir di salah satu perusahaan ternama di Indonesia.<br><br>
											Dengan bekal hard skill dan soft skill yang saya dapatkan di Fakultas Psikologi UJ,
											saya dapat menerapkan dan mengembangkannya di dunia kerja.<br><br>
											Semoga Fakultas Psikologi Universitas Jayabaya dapat terus berkembang.
											Maju terus Fakultas Psikologi UJ, jayalah  selalu!</p><br>
                    <div class="row">
                    <div class="col-sm-2">
                        <img src="images/Taufiq setyaji.jpg" class="img-responsive" style="width: 80px">
                        </div>
                        <div class="col-sm-10">
                        <h4><strong>Taufiq Setyaji</strong></h4>
                        <p class="testimonial_subtitle"><span>Recruitment & Training Supervisor</span><br>
                        <span>Indofood Asahi</span>
                        </p>
                    </div>
                    </div>
                  </div>
                </div>

								<div class="item">
                  <div class="row" style="padding: 20px">
                    <button style="border: none;"><i class="fa fa-quote-left testimonial_fa" aria-hidden="true"></i></button>
                    <p class="testimonial_para">Saya Widan Permana Septiadi, usia saat ini 30 tahun, bekerja sebagai
											Supervisor Selection & Recruitment di PT Sriwijaya Air, saya kuliah pada rentang tahun 2004-2010,
											dan pada saat masuk kuliah, angkatan saya terhitung sebagai angkatan kedua di Fakultas
											Psikologi Universitas Jayabaya, alasan saya mengambil kuliah jurusan Psikologi karena tertarik
											pada tingkah laku manusia. Sebelum mengenal dunia Psikologi saya selalu tertarik kenapa manusia
											bisa bertindak, mengambil keputusan, dan segala macam dinamika yang ada dalam kehidupan sehari-hari,
											jadi intinya setelah mengetahui bahwa pola pikir dan sikap manusia ada ilmunya,
											saya menjadi tertarik untuk mengetahui dan mempelajarinya.<br><br>

											Banyak ilmu yang saya dapatkan (meskipun tidak semuanya terserap dengan baik) dan sangat berguna
											bagi saya, baik dalam kehidupan pribadi maupun dunia kerja yang saya jalani saat ini.
											Overall, kuliah di Fakultas Psikologi Universitas Jayabaya sangat menyenangkan,
											Dosen yang capable (Karena mayoritas Dosen saya pada saat itu berasal dari Dosen Fakultas Psikologi
											UNPAD Bandung), teman sekelas yang selalu support, suasana kekeluargaan antara Dosen dan Mahasiswa,
											dan model belajar yang imbang antara teori dan praktek, semua itu sangat membantu saya dalam
											mempelajari bidang ilmu ini. Semoga ke depannya Fakultas Psikologi Universitas Jayabaya dapat
											terus berkembang, dapat melahirkan sarjana Psikologi yang berguna bagi masyarakat, dan semakin
											menunjukkan eksistensinya dalam dunia Psikologi di Indonesia.
											Suskes Selalu Jayabaya, maju terus Fakultas Psikologi ku<br><br>
											</p><br>
                    <div class="row">
                    <div class="col-sm-2">
                        <img src="images/Widan.jpg" class="img-responsive" style="width: 80px">
                        </div>
                        <div class="col-sm-10">
                        <h4><strong>Widan Permana</strong></h4>
                        <p class="testimonial_subtitle"><span>Fak Psikologi Angkatan 2004</span><br>
                        <span>Institusi : PT Sriwijaya Air, Jakarta</span>
                        </p>
                    </div>
                    </div>
                  </div>
                </div>

               <div class="item">
                   <div class="row" style="padding: 20px">
                    <button style="border: none;"><i class="fa fa-quote-left testimonial_fa" aria-hidden="true"></i></button>
                    <p class="testimonial_para">Testimoni Kuliah di Psikologi Universitas Jayabaya :<br><br>
											Saya belajar hal-hal teoritis maupun praktis dari dosen yang memiliki dedikasi tinggi,
											dan menyediakan waktu untuk konsultasi skripsi, organisasi maupun masalah pribadi.
											Para dosen dan mahasiswa dapat berkomunikasi langsung dan bersifat kekeluargaan.
											Mahasiswa diberi kesempatan untuk melatih kemampuan dirinya di organisasi BEM/BPM Fakultas Psikologi,
											magang dalam pelaksanaan tes psikologi dan berhadapan langsung dengan peserta tes
											(calon karyawan dari perusahaan kien). Fasilitasnya cukup dimanfaatkan oleh mahasiswa seperti
											lab psikologi, alat tes psikologi dan ruang belajar yang nyaman.<br><br>

											Testimoni Pekerjaan dan Jabatan Saat Ini :<br><br>
											Saya bekerja dalam bidang psikologi klinis anak, sebagai guru dan observer Psikologi,
											disana saya berinteraksi dengan anak-anak penyandang autisme, down syndrome,
											attention deficit disorder (ADD), attention deficit hyperactive disorder (ADHD),
											global development delay (GDD), speech delay, cerebral palsy, microcephaly dan lain-lain.
											Saya mengajarkan materi akademis maupun non akademis.
											Bekerja dengan orang asing dan terkadang dibantu oleh mahasiswa/i semester akhir yang magang
											dari fakultas Psikologi atau Special Needs dari Australia ataupun Amerika yang ingin
											belajar tentang anak special needs secara langsung.
											Selain itu saya juga bekerja freelanc di Biro Psikologi sebagai assistant Psikolog dan melakukan
											tes psikologi pada perusahaan maupun sekolah.
										</p><br>
                    <div class="row">
                    <div class="col-sm-2">
                        <img src="images/Surayya.jpg" class="img-responsive" style="width: 80px">
                        </div>
                        <div class="col-sm-10">
                        <h4><strong>Surayya Sakinah, S.Psi</strong></h4>
                        <p class="testimonial_subtitle"><span>Angkatan : 2011 Tahun Lulus : 2015</span><br>
                        <span></span>
                        </p>
                    </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="controls testimonial_control pull-right">
                <a class="left fa fa-chevron-left btn btn-default testimonial_btn" href="#carousel-example-generic"
                  data-slide="prev"></a>

                <a class="right fa fa-chevron-right btn btn-default testimonial_btn" href="#carousel-example-generic"
                  data-slide="next"></a>
              </div>
        </div>
	</div>
</div>
	<!-- //testimonials -->

<br/><br/>

	<!-- subscribe -->
	<div class="w3layouts_bottom">
		<div class="container">
			<div class="col-md-9 w3layouts_getin_info">
				<h3>Daftar menjadi mahasiswa sekarang!!</h3>
			</div>
			<div class="col-md-3 w3layouts_getin">
				<a href="#" data-toggle="modal" data-target="#myModal3">Daftar</a>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
	<!-- //subscribe -->


  <!-- footer -->
  <div class="footer">
    <div class="container">
      <div class="w3_agile_footer_grids">

      <div class="w3ls_address_mail_footer_grids">
        <div class="col-md-4 w3ls_footer_grid_left">
          <div class="wthree_footer_grid_left">
            <a href="#"><i class="fa fa-map-marker" aria-hidden="true"></i>
          </div>
          <p>Jl. Pulomas Selatan Kav. 23, <span>Jakarta Timur, 13210</span></p></a>
        </div>
        <div class="col-md-4 w3ls_footer_grid_left">
          <div class="wthree_footer_grid_left">
            <i class="fa fa-phone" aria-hidden="true"></i>
          </div>
          <p>+62 21 4700 890 <span>+62 21 4700 890</span></p>
        </div>
        <div class="col-md-4 w3ls_footer_grid_left">
          <div class="wthree_footer_grid_left">
            <i class="fa fa-envelope-o" aria-hidden="true"></i>
          </div>
          <p><a href="mailto:psikologi@jayabaya.ac.id">psikologi@jayabaya.ac.id</a>
            <span><a href="mailto:psi_ujb@yahoo.com">psi_ujb@yahoo.com</a></span></p>
        </div>
        <div class="clearfix"> </div>
      </div>
      <div class="agileinfo_copyright">
        <p>Copyright © 2017 Fakultas Psikologi Jayabaya | <a href="www.psikologi.jayabaya.ac.id">www.psikologi.jayabaya.ac.id</a></p>
      </div>
    </div>
  </div>
  <!-- //footer -->
  <!-- menu -->
  <!-- js -->
  <script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
  <script type="text/javascript" src="js/modernizr.custom.46884.js"></script>
  <!-- password-script -->
  <script type="text/javascript">
    window.onload = function () {
      document.getElementById("password1").onchange = validatePassword;
      document.getElementById("password2").onchange = validatePassword;
    }

    function validatePassword() {
      var pass2 = document.getElementById("password2").value;
      var pass1 = document.getElementById("password1").value;
      if (pass1 != pass2)
        document.getElementById("password2").setCustomValidity("Passwords Don't Match");
      else
        document.getElementById("password2").setCustomValidity('');
      //empty string means no validation error
    }
  </script>
  <!-- //password-script -->

  <!-- //js -->
  <script src="js/bars.js"></script>

  <script type="text/javascript" src="js/jquery.slicebox.js"></script>
  <script type="text/javascript">
    $(function () {

      var Page = (function () {

        var $navArrows = $('#nav-arrows').hide(),
          $navDots = $('#nav-dots').hide(),
          $nav = $navDots.children('span'),
          $shadow = $('#shadow').hide(),
          slicebox = $('#sb-slider').slicebox({
            onReady: function () {

              $navArrows.show();
              $navDots.show();
              $shadow.show();

            },
            onBeforeChange: function (pos) {

              $nav.removeClass('nav-dot-current');
              $nav.eq(pos).addClass('nav-dot-current');

            }
          }),

          init = function () {

            initEvents();

          },
          initEvents = function () {

            // add navigation events
            $navArrows.children(':first').on('click', function () {

              slicebox.next();
              return false;

            });

            $navArrows.children(':last').on('click', function () {

              slicebox.previous();
              return false;

            });

            $nav.each(function (i) {

              $(this).on('click', function (event) {

                var $dot = $(this);

                if (!slicebox.isActive()) {

                  $nav.removeClass('nav-dot-current');
                  $dot.addClass('nav-dot-current');

                }

                slicebox.jump(i + 1);
                return false;

              });

            });

          };

        return {
          init: init
        };

      })();

      Page.init();

    });
  </script>
  <!-- Stats -->
  <script src="js/waypoints.min.js"></script>
  <script src="js/counterup.min.js"></script>
  <script>
    jQuery(document).ready(function ($) {
      $('.counter').counterUp({
        delay: 10,
        time: 2000
      });
    });
  </script>
  <!-- //Stats -->

  <script type="text/javascript" src="js/jquery.flexisel.js"></script>
  <!-- flexisel -->
  <script type="text/javascript">
    $(window).load(function () {
      $("#flexiselDemo1").flexisel({
        visibleItems: 4,
        animationSpeed: 1000,
        autoPlay: true,
        autoPlaySpeed: 3000,
        pauseOnHover: true,
        enableResponsiveBreakpoints: true,
        responsiveBreakpoints: {
          portrait: {
            changePoint: 480,
            visibleItems: 1
          },
          landscape: {
            changePoint: 640,
            visibleItems: 2
          },
          tablet: {
            changePoint: 768,
            visibleItems: 2
          }
        }
      });

    });
  </script>
  <!-- //flexisel -->
  <!-- //flexisel -->
  <!-- js for portfolio lightbox -->
  <script src="js/jquery.chocolat.js "></script>
  <!-- //menu -->
  <!-- for bootstrap working -->
  <script src="js/bootstrap.js"></script>
  <!-- //for bootstrap working -->
  <!-- start-smoth-scrolling -->
  <script type="text/javascript" src="js/move-top.js"></script>
  <script type="text/javascript" src="js/easing.js"></script>
  <script type="text/javascript">
    jQuery(document).ready(function ($) {
      $(".scroll").click(function (event) {
        event.preventDefault();
        $('html,body').animate({
          scrollTop: $(this.hash).offset().top
        }, 1000);
      });
    });
  </script>
  <!-- start-smoth-scrolling -->
  <!-- here stars scrolling icon -->
  <script type="text/javascript">
    $(document).ready(function () {
      /*
        var defaults = {
        containerID: 'toTop', // fading element id
        containerHoverID: 'toTopHover', // fading element hover id
        scrollSpeed: 1200,
        easingType: 'linear'
        };
      */

      $().UItoTop({
        easingType: 'easeOutQuart'
      });

    });
  </script>
  <!-- //here ends scrolling icon -->

  </body>

  </html>
