<?php
error_reporting(0);
session_start();
include "koneksi.php";
$email= $_POST['email'];
$password = $_POST['password'];
$op = $_GET['op'];

if($op=="in"){
    $sql = mysql_query("SELECT * FROM mahasiswa WHERE email='$email' AND password='$password'");

        if(mysql_num_rows($sql)==1){//jika berhasil akan bernilai 1
            $qry = mysql_fetch_array($sql);
            $_SESSION['nama'] = $qry['nama'];
            $_SESSION['email'] = $qry['email'];

                if($qry){
                    header("location:home.php");

                }

                }else{
                ?>
<script language="JavaScript">
    alert('Username atau Password tidak sesuai. Silahkan diulang kembali!');
    document.location='index.php';
</script>
<?php
}
}else if($op=="out"){
    unset($_SESSION['nama']);
    unset($_SESSION['email']);

    header("location:index.php");
}
?>
