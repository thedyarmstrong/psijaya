<?php
include "koneksi.php";

// Cek apakah form sudah di submit atau belum
if(isset($_POST['SUBMIT'])){

	$judul=$_POST['nama'];

// Cek apakah inputan gambar kosong atau tidak
    if(!empty($_FILES["img"]["tmp_name"])||!empty($judul)||!empty($isi)||!empty($link)){
    // Folder yang dituju



    // Nama file
    $nama_file=$_FILES["img"]["name"];
    // Temporary pada file
    $lokasi_file=$_FILES["img"]["tmp_name"];
    // Ekstensi file
    $type_file=$_FILES["img"]["type"];
    //Ukuran file yang diperbolehkan ( 1 Mb )

    // Tujuan
    $direktori="../images/$nama_file";
    // Cek ukuran file

    // Cek ekstensi pada file, misalnya hanya diperbolehkan untuk ekstensi gambar
          if($type_file == "image/png" or $type_file == "image/jpg" or $type_file == "image/jpeg" )
          {
    // Proses upload gambar
              if(move_uploaded_file($lokasi_file,$direktori))
              {

                  $insert=mysql_query("INSERT INTO banner VALUES (null,'$nama_file','$judul')");
                  ?>
                  <script language="javascript">alert("Berhasil");</script>
                  echo "<meta http-equiv='refresh' content='0; url=home.php?page=11'>";
                  <?php

              }else{
              echo "Tambah Berita Gagal";
              }
          }
          else
          {
            ?>
            <script language="javascript">alert("Ekstensi file hanya diperbolehkan png, jpg, jpeg, dan gif");</script>
            <?php
          }

    }
    else{
      ?>
      <script language="javascript">alert("Data Belum Lengkap");</script>
      <?php
    }
}

?>


<h1>Tambah Banner Baru</h1>

<div class="table-responsive">
	<form method="post" action="home.php?page=12" enctype="multipart/form-data" name="form1" id="form1">
		<table id="example" class="table table-hover table-striped table-bordered" cellspacing="0" width="100%">
	        <tr>
	            <td>Foto :</td>
	            <td><label for="foto"></label>
	                <input type="file" name="img" />
	            </td>
	        </tr>
	        <tr>
				<td valign="top">Judul Banner :</td>
				<td><input type="text" size="100"  name="nama"></td>
			</tr>
		</table>
	<p align="center">
        <input type="submit" value="submit" name="SUBMIT"  />
   	</p>
	</form>
</div>