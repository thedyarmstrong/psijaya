<?php

$host="localhost";
$user="psikaaci_psikologi";
$pass="psikologi123";
$db="psikaaci_psikologi";


$koneksi=mysql_connect($host,$user,$pass);
$database=mysql_select_db($db,$koneksi);
$tanggal=date('d-M-y');
/*
if ($koneksi)
{
	echo "berhasil : )";
}else{
	echo "Gagal !";
}
*/
?>
