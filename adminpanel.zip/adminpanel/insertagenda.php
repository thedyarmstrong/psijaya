<?php
error_reporting(0);
 include ('koneksi.php');


  $agenda=$_POST['agenda'];



  //periksa apakah udah submit
  if (isset($_POST['SUBMIT']))
  {

      $insert=mysql_db_query($db,"INSERT INTO agenda(agen) VALUES ('$agenda')",$koneksi);

      //jika sudah berhasil
      if ($insert)
      {
        echo "<script> document.location.href='home.php?page=16'; </script>";
      }else{
        echo "GAGAL";
      }
    }

?>

<h1>Berita Baru</h1>

<div class="table-responsive">
	<form method="post" action="home.php?page=14" name="form1" id="form1">
		<table id="example" class="table table-hover table-striped table-bordered" cellspacing="0" width="100%">
			<tr>
				<td valign="top">Agenda :</td>
				<td><input type="text" size="100" name="agenda"></td>
			</tr>
		</table>
	<p align="center">
        <input type="submit" value="submit" name="SUBMIT"  />
   	</p>
	</form>
</div>
