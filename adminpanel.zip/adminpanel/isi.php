<?php
include "koneksi.php";
$page=$_GET['page'];

switch($page)
{
	case "1";
	break;

	case "2";
	include "datamahasiswa.php";
	break;

	case "3";
	include "cekpembayaran.php";
	break;

	case "4";
	include "proses_pembayaran.php";
	break;

	case "5";
	include "berita.php";
	break;

	case "6";
	include "tambah_berita.php";
	break;

	case "7";
	include "del_berita.php";
	break;

	case "8";
	include "kegiatan.php";
	break;

	case "9";
	include "insertkegiatan.php";
	break;

	case "10";
	include "del_kegiatan.php";
	break;

	case "11";
	include "banner.php";
	break;

	case "12";
	include "insertbanner.php";
	break;

	case "13";
	include "del_banner.php";
	break;

	case "14";
	include "insertagenda.php";
	break;

	case "15";
	include "del_agenda.php";
	break;
	
	case "16";
	include "agenda.php";
	break;
}
?>
