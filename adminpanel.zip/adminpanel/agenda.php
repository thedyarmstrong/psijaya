<h1>Agenda Psikologi</h1>
<a href="home.php?page=14">Buat Agenda Baru</a>
<div class="table-responsive">
<table id="agenda" class="table table-hover table-striped table-bordered" cellspacing="0" width="100%">
      <thead>
          <tr>
              <th>No.</th>
              <th>Agenda</th>
          </tr>
      </thead>

  <tbody>
    <?php
    include "koneksi.php";

    $query = mysql_query("SELECT * FROM agenda ORDER BY noid DESC");
    $i=1;

    while($d = mysql_fetch_array($query)){?>
      <tr>
          <td><?php echo $i++; ?></td>
          <td><?php echo $d['agen']; ?></td>
          <td><a href="home.php?page=15&id=<?php echo $d['noid'];?>">Hapus</a></td>
      </tr>
    <?php
    }
    ?>
  </tbody>
</table>



<script src="http://code.jquery.com/jquery-1.12.0.min.js"></script>
<script src="//cdn.datatables.net/1.10.11/js/jquery.dataTables.min.js"></script>
<script>
$(document).ready(function() {
  $('#agenda').DataTable( {
      initComplete: function () {
          this.api().columns().every( function () {
              var column = this;
              var select = $('<select><option value=""></option></select>')
                  .appendTo( $(column.footer()).empty() )
                  .on( 'change', function () {
                      var val = $.fn.dataTable.util.escapeRegex(
                          $(this).val()
                      );

                      column
                          .search( val ? '^'+val+'$' : '', true, false )
                          .draw();
                  } );

              column.data().unique().sort().each( function ( d, j ) {
                  select.append( '<option value="'+d+'">'+d+'</option>' )
              } );
          } );
      }
  } );
} );
</script>
